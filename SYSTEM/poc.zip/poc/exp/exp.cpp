﻿#include <Windows.h>
#include <stdio.h>
#include "resource.h"

bool ReleaseResource(UINT uResourceId, const WCHAR* szResourceType, WCHAR* szFileName) {

	// HRSRC hRsrc = FindResource(NULL, MAKEINTRESOURCE(IDR_HELPER_BIN1), L"helper_bin");
	HRSRC hRsrc = FindResource(NULL, MAKEINTRESOURCE(uResourceId), szResourceType);
	if (hRsrc == NULL) {
		wprintf(L"FindResource error: %d\n", GetLastError());
		return FALSE;
	}

	DWORD dwSize = SizeofResource(NULL, hRsrc);
	if (dwSize <= 0) {
		CloseHandle(hRsrc);
		wprintf(L"SizeOfResource error: %d\n", GetLastError());
		return FALSE;
	}

	HGLOBAL hGlobal = LoadResource(NULL, hRsrc);
	if (hGlobal == NULL) {
		CloseHandle(hRsrc);
		wprintf(L"LoadResource error: %d\n", GetLastError());
		return FALSE;
	}

	LPVOID lpRes = LockResource(hGlobal);
	if (lpRes == NULL) {
		CloseHandle(hRsrc);
		CloseHandle(hGlobal);
		wprintf(L"LockResource error: %d\n", GetLastError());
		return FALSE;
	}

	// HANDLE hFile = CreateFile(L".\\helper.exe", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	HANDLE hFile = CreateFile(szFileName, GENERIC_READ | GENERIC_WRITE, NULL, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {

		wprintf(L"CreateFile(%s) error: %d\n", szFileName, GetLastError());
		CloseHandle(hRsrc);
		CloseHandle(hGlobal);
		return FALSE;
	}

	DWORD dwWriten = 0;
	BOOL bRes = WriteFile(hFile, lpRes, dwSize, &dwWriten, NULL);
	if (bRes == FALSE || dwWriten <= 0) {
		CloseHandle(hRsrc);
		CloseHandle(hGlobal);
		CloseHandle(hFile);
		wprintf(L"WriteFile error: %d\n", GetLastError());
		return FALSE;
	}

	CloseHandle(hRsrc);
	CloseHandle(hGlobal);
	CloseHandle(hFile);

	return TRUE;
}

int wmain() {
	WCHAR helper[] = L".\\helper.exe\x00";
	WCHAR poc[] = L".\\poc.exe\x00";
	if (ReleaseResource(IDR_HELPER_BIN1, L"helper_bin", helper) && ReleaseResource(IDR_POC_BIN1, L"poc_bin", poc)) {
		Sleep(5000);
		WinExec(".\\helper.exe", SW_SHOW);
		Sleep(5000);
		WinExec(".\\poc.exe", SW_SHOW);
		Sleep(5000);
		// system("type C:\\Windows\\win.ini");
		(void)getchar();
	}
	else {
		wprintf(L"ReleaseResource failed\n");
		Sleep(500000);
		return -1;
	}

	/*
	STARTUPINFO sih;
	PROCESS_INFORMATION pih;
	ZeroMemory(&sih, sizeof(sih));
	ZeroMemory(&pih, sizeof(pih));
	sih.cb = sizeof(sih);
	sih.dwFlags = STARTF_USESHOWWINDOW;
	sih.wShowWindow = SW_SHOW;
	if (!CreateProcess(NULL,
		helper,
		NULL,
		NULL,
		FALSE,
		0,
		NULL,
		NULL,
		&sih,
		&pih
	)) {
		wprintf(L"CreateProcess error: %d\n", GetLastError());
		CloseHandle(pih.hProcess);
		CloseHandle(pih.hThread);
		return -1;
	}

	STARTUPINFO sip;
	PROCESS_INFORMATION pip;
	ZeroMemory(&sip, sizeof(sip));
	ZeroMemory(&pip, sizeof(pip));
	sip.cb = sizeof(sip);
	sip.dwFlags = STARTF_USESHOWWINDOW;
	sip.wShowWindow = SW_SHOW;
	if (!CreateProcess(NULL,
		helper,
		NULL,
		NULL,
		FALSE,
		0,
		NULL,
		NULL,
		&sip,
		&pip
	)) {
		wprintf(L"CreateProcess error: %d\n", GetLastError());
		CloseHandle(pip.hProcess);
		CloseHandle(pip.hThread);
		return -1;
	}
	*/

	// ugly code but I don't care
	return 0;
}